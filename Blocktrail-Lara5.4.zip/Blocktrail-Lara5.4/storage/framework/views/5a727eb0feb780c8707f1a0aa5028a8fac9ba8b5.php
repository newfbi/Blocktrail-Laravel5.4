<?php $__env->startSection('title'); ?>
    Simple Bitcoin Wallet - Confirm Payment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <div class="row">
                <div class="eight offset-by-two columns">
                    <h1 class="text-center">Please Confirm</h1>
                    <p>
                        You are about to make a payment of <?php echo e($amount); ?> Satoshi (
                        <span class="btc-value"><?php echo Blocktrail::toBTCString($amount); ?></span> BTC
                        ) to the address <code><?php echo e($address); ?></code>. <br/>
                        Please enter in your password below to continue with this payment.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="eight offset-by-two columns">
                    <?php echo e(Form::open(array('route' => array('wallet.confirm-send', $wallet->id), 'method' => 'post', 'novalidate' => 'true'))); ?>

                        <?php echo e(Form::hidden('address', Input::old('address'), array('placeholder' => 'bitcoin address', 'class' => 'u-full-width'))); ?>

                        <?php echo e(Form::hidden('amount', Input::old('amount'), array('placeholder' => 'amount', 'class' => 'u-full-width'))); ?>

                        <?php echo e(Form::password('password',  array('placeholder' => 'password', 'class' => 'u-full-width'))); ?>

                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                        <div class="error u-pull-left"><?php echo e($errors->first('general')); ?></div>

                        <?php echo e(Form::submit('Make Payment', array('class' => 'button-primary u-pull-right'))); ?>

                        <a class="button u-pull-right margin-r" href="<?php echo e(URL::route('wallet.send', $wallet->id)); ?>">Cancel</a>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
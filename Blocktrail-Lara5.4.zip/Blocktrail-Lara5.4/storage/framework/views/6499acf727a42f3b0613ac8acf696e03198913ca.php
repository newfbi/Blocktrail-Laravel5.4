<?php $__env->startSection('title'); ?>
    Simple Bitcoin Wallet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <h1></h1>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="six offset-by-three columns">
                    <h2 class="section-heading">Login</h2>
                    <?php if($errors->count() > 0): ?>
                        <h6>Please check your input</h6>
                    <?php endif; ?>
                    <?php echo e(Form::open(array('route' => 'login', 'method' => 'post', 'novalidate' => 'true'))); ?>

                    <div class="error"><?php echo e($errors->first('email')); ?></div>
                    <?php echo e(Form::email('email', Input::old('email'), array('placeholder' => 'you@domain.com', 'class' => 'u-full-width'))); ?>

                    <div class="error"><?php echo e($errors->first('password')); ?></div>
                    <?php echo e(Form::password('password',  array('placeholder' => 'password', 'class' => 'u-full-width'))); ?>

                    <?php echo e(Form::submit('login', array('class' => 'u-pull-right'))); ?>

                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>

    <section></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
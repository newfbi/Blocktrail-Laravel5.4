<?php $__env->startSection('title'); ?>
    Simple Bitcoin Wallet - Confirm Payment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <?php if(isset($transaction)): ?>
            <h1>Payment Sent!</h1>
            <p>
                Your payment was successfully sent!<br/>
                You can see it on the <a href="<?php echo e(URL::route('transaction', $transaction)); ?>" target="_blank">block explorer</a>.
            </p>
            <a class="button u-pull-right" href="<?php echo e(URL::route('dashboard')); ?>">Done</a>
            <?php else: ?>
                <h1>Payment Failed</h1>
                <p>
                    There was a problem sending your transaction.<br/>
                    <?php echo e($errors->first('general')); ?>

                </p>
                <a class="button u-pull-right-s" href="<?php echo e(URL::route('dashboard', $wallet->id)); ?>">Cancel</a>
                <a class="button u-pull-right-s" href="<?php echo e(URL::route('wallet.send', $wallet->id)); ?>">Edit Payment</a>
            <?php endif; ?>
        </div>
    </section>


    <section></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
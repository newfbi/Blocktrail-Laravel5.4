<?php $__env->startSection('title'); ?>
    Simple Bitcoin Wallet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <h3 class="section-heading">Hi There <?php echo e(ucfirst(Auth::user()->fname)); ?> <?php echo e(ucfirst(Auth::user()->lname)); ?></h3>
            <p>
                Ready to spend some bitcoin?
            </p>
            <?php if($wallets->count() > 0): ?>
            <a class="button button-primary" href="<?php echo e(URL::route('wallet.send', $wallets[0]['id'])); ?>">Quick Send</a>
            <a class="button button-primary" href="<?php echo e(URL::route('wallet.receive', $wallets[0]['id'])); ?>">Quick Receive</a>
            <?php else: ?>
                <a class="button button-primary" href="<?php echo e(URL::route('wallet.create')); ?>">Create A Wallet</a>
            <?php endif; ?>
            <hr/>
        </div>
    </section>

    <section>
        <div class="container">
            <h4 class="section-heading">Wallets</h4>
            <p>You have <b><?php echo e($wallets->count()); ?></b> wallets with a total balance of <span class="btc-value"><?php echo Blocktrail::toBTCString($totalBalance); ?></span> BTC</p>
            <table class="u-full-width blocks">
                <thead>
                <tr>
                    <th><div>Name</div></th>
                    <th><div>Balance</div></th>
                    <th><div>Pending Transactions</div></th>
                    <th><div></div></th>
                    <th><div></div></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($wallet['name']); ?></td>
                        <td><span class="btc-value"><?php echo Blocktrail::toBTCString($wallet['balance']); ?></span> BTC</td>
                        <td><span class="btc-value"><?php echo Blocktrail::toBTCString($wallet['unc_balance']); ?></span> BTC</td>
                        <td><a class="button" href="<?php echo e(URL::route('wallet.send', $wallet['id'])); ?>">Send Payment</a></td>
                        <td><a class="button" href="<?php echo e(URL::route('wallet.receive', $wallet['id'])); ?>">Receive Payment</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a class="button u-pull-right" style="margin-right: 3.5em;" href="<?php echo e(URL::route('wallet.create')); ?>">New Wallet</a>
        </div>
    </section>

    <section>
        <div class="container" id="history">
            <h4 class="section-heading">History</h4>
            <p class="padding-b">Below is the transaction history involving your wallets.</p>

            <div class="scroll-window">
                <table class="u-full-width fixed-header transactions">
                    <thead>
                    <tr>
                        <th><div>Date</div></th>
                        <th><div>Info</div></th>
                        <th><div>Amount</div></th>
                        <th><div>Confirmations</div></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <td>Date</td>
                        <td>Info</td>
                        <td>Amount</td>
                        <td>Confirmations</td>
                        <td></td>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo \Carbon::parse($tx['created_at'])->format('d M, Y H:i'); ?></td>
                            <td>
                                <?php if($tx['direction'] == "sent"): ?>
                                Sent from <b><?php echo e($tx['wallet']['name']); ?></b> to <a href="<?php echo e(URL::route('address', $tx['recipient'])); ?>"><?php echo e(substr($tx['recipient'], 0, 8)); ?></a>...
                                <?php elseif($tx['direction'] == "received"): ?>
                                Receieved into <b><?php echo e($tx['wallet']['name']); ?></b>
                                <?php elseif($tx['direction'] == "internal"): ?>
                                    Internal transaction with <b><?php echo e($tx['wallet']['name']); ?></b>: <a href="<?php echo e(URL::route('address', $tx['recipient'])); ?>"><?php echo e(substr($tx['recipient'], 0, 8)); ?></a>
                                <?php endif; ?>
                            </td>
                            <td class="<?php echo e($tx['amount'] > 0 ? 'output' : 'input'); ?>"><span class="btc-value"><?php echo Blocktrail::toBTCString($tx['amount']); ?></span> BTC</td>
                            <td><?php echo e($tx['confirmations']); ?></td>
                            <td><a href="<?php echo e(URL::route('transaction', $tx['tx_hash'])); ?>">view transaction</a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($transactions->fragment('history')->links()); ?>


        </div>
    </section>

    <section></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
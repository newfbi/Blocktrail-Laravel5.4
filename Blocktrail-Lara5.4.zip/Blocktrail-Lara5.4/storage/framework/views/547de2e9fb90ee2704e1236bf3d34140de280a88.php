<?php $__env->startSection('title'); ?>
    Simple Bitcoin Wallet - Send Payment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <div class="row">
                <div class="eight offset-by-two columns">
                    <h1>Send Payment</h1>
                    <p>
                        Ready to send a payment from your wallet <b>'<?php echo e($wallet->name); ?>'</b>. <br/>
                        You have a confirmed balance of <span class="btc-value"><?php echo Blocktrail::toBTCString($wallet->balance); ?></span> BTC <br/><br/>
                        You have a confirmed balance of <span class="btc-value"><?php echo Blocktrail::toBTCString($soma); ?></span> BTC <br/>
                        <?php if($wallet->unc_balance): ?>
                            <small>there is <span class="btc-value"><?php echo Blocktrail::toBTCString($wallet->unc_balance); ?></span> BTC in pending transactions</small>
                        <?php endif; ?>
                    </p>
                    <hr/>
                </div>
            </div>

            <div class="row">
                <div class="eight offset-by-two columns">
                    <?php echo e(Form::open(array('route' => array('wallet.send', $wallet->id), 'method' => 'post', 'novalidate' => 'true'))); ?>


                    <?php echo e(Form::label('address', "Recipient Address")); ?>

                    <?php echo e(Form::text('address', Input::old('address'), array('placeholder' => 'bitcoin address', 'class' => 'u-full-width'))); ?>


                    <?php echo e(Form::label('amount', "Amount in Satoshi")); ?>

                    <div><small><i>1BTC = 100000000 Satoshi</i></small></div>
                    <?php echo e(Form::number('amount', Input::old('amount'), array('placeholder' => 'amount', 'class' => 'u-full-width'))); ?>


                    <div class="error u-pull-left">
                        <div><?php echo e($errors->first('address')); ?></div>
                        <div><?php echo e($errors->first('amount')); ?></div>
                        <div><?php echo e($errors->first('general')); ?></div>
                    </div>

                    <?php echo e(Form::submit('Send Payment', array('class' => 'button-primary u-pull-right'))); ?>

                    <a class="button u-pull-right margin-r" href="<?php echo e(URL::route('dashboard')); ?>">Cancel</a>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
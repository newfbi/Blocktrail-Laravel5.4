<?php

namespace App\Http\Controllers;
use Blocktrail;
use App\User;
use Auth;
class HomeController extends Controller {

	 
	private $bitcoinClient;

	public function __construct(Blocktrail $client) {
		$this->middleware('auth');
		$this->bitcoinClient = $client;
	}

	public function showDashboard()
	{
		//get the user's wallets and their balances
		$user = User::find(Auth::user()->id);
		$wallets = $user->wallets;
		//lets also add up the balances of all wallets
		$totalBalance = 0;
		$totalUncBalance = 0;
		$wallets->each(function($wallet) use(&$totalBalance, &$totalUncBalance){
			$wallet->getBalance();
			$totalBalance += $wallet->balance;
			$totalUncBalance += $wallet->unc_balance;
		});

		//get the user's transaction history (paginated)
		$user->transactions = $user->transactions()->with(array('wallet' => function($query){
			$query->select(['id', 'name']);
		}))->orderBy('tx_time', 'desc')->paginate(10);

		$data = [			'wallets' => $wallets,
			'transactions' => $user->transactions,
			'totalBalance' => $totalBalance,
			'totalUncBalance' => $totalUncBalance,
		];

		return view('dashboard.home')->with($data);
	}
}

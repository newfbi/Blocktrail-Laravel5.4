<?php

namespace App\Http\Controllers;

use Blocktrail;
use Auth;
use Hash;
use Session;
use Validator;
use App;
use Config;
use URL;
use Redirect;
use \App\Models\Wallet;
use \App\Models\Webhook;
use User;
use Input;

use Illuminate\Support\MessageBag;

class WalletController extends Controller {

    private $bitcoinClient;

    public function __construct(Blocktrail $client) {
        $this->bitcoinClient = $client;
    }

    public function showNewWallet()
    {
        return view('wallet.new');
    }

    public function createNewWallet()
    {
        //create new wallet
        $user = Auth::user();
        $walletData = array(
            'identity' => str_random(40),
            'name' => $user->name,
            'pass' => str_random(6),
            'user_id' => $user->id
        );
        $wallet = New \App\Models\Wallet($walletData);
        if ($wallet->save()) {

            $data['newWallet'] = $wallet;

            $url = URL::route('webhook', ['wallet_identity' => $wallet->identity]);
        
            $newWebhook = Webhook::create(['identifier' => $wallet->identity, 'url' => $url, 'wallet_id' => $wallet->id]);

            //return the view with new wallet data
            return view('wallet.new')->with($data)->withErrors(Session::get('webhook-error'));
        } else {
            //could not create wallet
            return view('wallet.new')->withErrors(Session::get('wallet-error'));
        }
    }

    public function showWallet($wallet)
    {
        $data = [];
        return view('wallet.edit')->with($data);
    }

    public function updateWallet($wallet)
    {
        //
    }

    public function showSendPayment($wallet)
    {
        $wallet->getBalance();
        $data['wallet' ] = $wallet;
        $balance = $wallet->balance;
        $data['soma'] = $balance - 48000;

        return view('wallet.send', $data);
    }

    public function sendPayment($wallet)
    {
        //Validate the input then send the user to confirm the payment
        $rules = array(
            'address' => 'required|regex:/^[a-km-zA-HJ-NP-Z0-9]{26,35}$/i',
            'amount' => 'required|integer|min:1'
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            //bad input
            return Redirect::route('wallet.send', $wallet->id)->withInput()->withErrors($validator);
        }

        //flash the input for next request, and show the confirmation view
        Input::flash();
        $data = [
            'wallet' => $wallet,
            'address' => Input::get('address'),
            'amount' => Input::get('amount'),
        ];
        return view('wallet.payment-confirm')->with($data);

    }

    public function confirmPayment($wallet)
    {
        //validate wallet owners' password
        if (!Hash::check(Input::get('password'), Auth::user()->password) ) {
            Input::flashExcept('password');
            $data = [
                'wallet' => $wallet,
                'address' => Input::get('address'),
                'amount' => Input::get('amount'),
            ];
            $errors =  new MessageBag(array('general' => 'Password is incorrect'));
            return view('wallet.payment-confirm')->with($data)->withErrors($errors);
        }

        //send off the payment
        try {
            $transaction = $wallet->pay(Input::get('address'), (int)Input::get('amount'));
            $data = [
                'transaction' => $transaction
            ];

            //add to the Transaction table
            $txData = array(
                'tx_hash' => $transaction,
                'tx_time' => Carbon::now(),
                'recipient' => Input::get('address'),
                'direction' => "sent",
                'amount' => -Input::get('amount'),
                'confirmations' => 0,
                'wallet_id' => $wallet->id,
            );
            Transaction::firstOrCreate($txData);

            //redirect to the success page (to avoid resubmitting payment on refresh)
            return Redirect::route('wallet.payment-result', $wallet->id)->withData($data);
        } catch (\Exception $e) {
            //an error occurred
            Input::flashExcept('password');
            $data = [
                'wallet' => $wallet,
            ];
            $errors =  new MessageBag(array('general' => $e->getMessage()));
            return view('wallet.payment-result')->with($data)->withErrors($errors);
        }
    }

    public function showPaymentResult($wallet)
    {
        //use an extra route here to ensure refreshing the page doesn't re-send the payment
        $data = Session::get('data');
        if (isset($data['transaction'])) {
            //payment was successful
            return view('wallet.payment-result')->with($data);
        } else {
            return Redirect::route('dashboard');
        }
    }

    public function showReceivePayment($wallet)
    {
        //get a new address to receive payments to
        $address = $wallet->getNewAddress();
        $data = [
            'wallet' => $wallet,
            'address' => $address
        ];
        return view('wallet.receive')->with($data);
    }

    public function sendPaymentRequest($wallet)
    {
        $data = [
            'wallet' => $wallet,
            'address' => Input::get('address')
        ];

        //validate input
        $rules = array(
            'email' => 'required|email',
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            //bad input
            Input::flash();
            return view('wallet.receive')->with($data)->withErrors($validator);
        }

        //send email
        $mailData = array(
            'recipient_email' => Input::get('email'),
            'payee_fname' => Auth::user()->fname,
            'payee_lname' => Auth::user()->lname,
            'payee_email' => Auth::user()->email,
            'msg'         => Input::get('message'),
            'address'     => Input::get('address'),
        );

        //return view('emails.wallet.request', $mailData);
        Mail::send('emails.wallet.request', $mailData, function($message) use($mailData){
            $message->from($mailData['payee_email'], $mailData['payee_fname'].' '.$mailData['payee_lname']);
            $message->to($mailData['recipient_email'])->subject('Please sent funds to my Bitcoin wallet');
        });

        //success
        return view('wallet.receive')->with($data)->with('email_sent', 'Request sent successfully');
    }

}

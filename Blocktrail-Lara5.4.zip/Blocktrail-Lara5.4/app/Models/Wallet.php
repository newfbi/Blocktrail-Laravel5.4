<?php

namespace App\Models;

//use Blocktrail\SDK\Connection\Exceptions\WalletExistsError;	//error doesn't exist yet
use Blocktrail\SDK\CreateNewWallet;
use Illuminate\Support\MessageBag;
use Illuminate\Database\Eloquent\Model;
use App;

class Wallet extends Model {

	protected $bitcoinClient;
	protected $liveWallet;

	protected $fillable = array(
		'identity',
		'name',
		'pass',
		'user_id'
	);

	public static $rules = array(
		'identity' 	=> 'alphanum|required',
		'pass'   	=> 'required|min:3',
	);

	public function __construct($attributes = array()) {
		parent::__construct($attributes);

		//initialise the bitcoin client
		$this->bitcoinClient = App::make('Blocktrail');
	}

	public static function boot()
	{
		parent::boot();

		static::creating(function($model)
		{
			$bitcoinClient = App::make('Blocktrail');
			//attempt to create the remote wallet first
			try {
				list($wallet, $blocktrailPublicKeys) = $bitcoinClient->CreateNewWallet($model->identity, $model->pass);
				$model->blocktrail_keys = $blocktrailPublicKeys;
			}

			catch (Exception $e) {
				//an error occured - add to any existing errors and flash to session
				$errors =  new MessageBag();
				$errors->add('general', 'Could not create wallet - '.$e->getMessage());
				Session::flash('wallet-error', $errors);
				return false;
			}
		});
	}


	/*---Relations---*/
	public function user()
	{
		return $this->belongsTo('User');
	}
	public function webhook()
	{
		return $this->hasOne('\App\Models\Webhook');
	}
	public function transactions()
	{
		return $this->hasMany('\App\Models\Transaction');
	}

	/*---Accessors and Mutators---*/
	public function setPasswordAttribute($value)
	{
		$this->attributes['password'] = Hash::make($value);
	}

	public function setBlocktrailKeysAttribute($value)
	{
		$this->attributes['blocktrail_keys'] = json_encode($value);
	}

	public function getBlocktrailKeysAttribute($value)
	{
		return json_decode($value, true);
	}

	/*--- Other functions ---*/
	public function initLiveWallet() {
		$this->liveWallet = $this->bitcoinClient->initWallet($this->identity, $this->pass);
	}

	public function getBalance() {
		if(!$this->liveWallet) {
			$this->initLiveWallet();
		}
		list($this->balance, $this->unc_balance) = $this->liveWallet->getBalance();
	}

	public function getNewAddress() {
		if(!$this->liveWallet) {
			$this->initLiveWallet();
		}
		return $this->liveWallet->getNewAddress();
	}

	public function pay($address, $amount) {
		if(!$this->liveWallet) {
			$this->initLiveWallet();
		}
		return $this->liveWallet->pay(array($address => $amount));
	}

}

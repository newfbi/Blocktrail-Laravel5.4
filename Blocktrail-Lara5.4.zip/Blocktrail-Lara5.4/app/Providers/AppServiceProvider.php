<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\View\Compilers\BladeCompiler;
use Blade;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        \Blade::extend(function($view, $compiler)
        {
            $pattern = $this->createOpenMatcher('datetime');
            return preg_replace($pattern, '$1<?php echo \Carbon::parse($2)->format(\'d M, Y H:i\'); ?>', $view);
        });
        /**
         * @toBTC($var)
         * formats the satoshi value as a Bitcoin string
         */
        \Blade::extend(function($view, $compiler)
        {
            $pattern = $this->createOpenMatcher('toBTC');
            return preg_replace($pattern, '$1<?php echo Blocktrail::toBTCString($2); ?>', $view);
        });
    }

    public function createOpenMatcher($function){
        return '/(?<!\w)(\s*)@'.$function.'\(\s*(.*)\)/';
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
